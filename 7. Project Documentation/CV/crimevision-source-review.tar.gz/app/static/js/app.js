
"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const state = {
    activeView: "image",
    cases: [],
    activeCaseId: "",
    currentResults: {
      image: null,
      audio: {
        transcription: null,
        events: null,
        semantic: null,
        timeline: null
      },
      video: null
    }
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) =>
    Array.from(root.querySelectorAll(selector));

  const viewConfig = {
    image: {
      title: "Image Analysis",
      description: "Examine image evidence using object detection and scene analysis."
    },
    audio: {
      title: "Audio Analysis",
      description: "Transcribe audio and extract events, semantic information, and timelines."
    },
    video: {
      title: "Video Analysis",
      description: "Analyze video evidence using sampled frames and object detection."
    },
    investigations: {
      title: "Investigations",
      description: "Manage investigations, registered evidence, and analysis records."
    },
    reports: {
      title: "Reports",
      description: "Review saved analysis records associated with investigations."
    }
  };

  function showNotice(message, type = "info") {
    const notice = $("#notice");
    if (!notice) return;

    notice.textContent = message;
    notice.className = `notice ${type}`;
    notice.hidden = false;
  }

  function clearNotice() {
    const notice = $("#notice");
    if (!notice) return;

    notice.textContent = "";
    notice.hidden = true;
  }

  function setStatus(element, message, type = "") {
    if (!element) return;

    element.textContent = message;
    element.className = "status-message";

    if (type) element.classList.add(type);
  }

  async function apiRequest(url, options = {}) {
    const response = await fetch(url, options);
    const contentType = response.headers.get("content-type") || "";

    let payload;

    if (contentType.includes("application/json")) {
      payload = await response.json();
    } else {
      payload = await response.text();
    }

    if (!response.ok) {
      const message =
        payload && typeof payload === "object"
          ? payload.error || payload.message
          : payload;

      throw new Error(
        message || `Request failed with HTTP ${response.status}.`
      );
    }

    return payload;
  }

 
function renderResult(container, data) {
  if (!container) return;

  container.replaceChildren();

  const element = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = String(text);
    return node;
  };

  const section = (title) => {
    const wrapper = element("section", "analysis-section");
    wrapper.appendChild(element("h3", "analysis-section-title", title));
    container.appendChild(wrapper);
    return wrapper;
  };

  const metric = (parent, label, value) => {
    const card = element("div", "metric-card");
    card.append(
      element("span", "metric-label", label),
      element("strong", "metric-value", value)
    );
    parent.appendChild(card);
  };

  const showImage = (parent, title, url, alt) => {
    const wrapper = element("div", "evidence-image-card");
    wrapper.appendChild(element("h4", "", title));

    const image = element("img", "evidence-result-image");
    image.alt = alt;
    image.loading = "lazy";
    image.src = url;

    image.addEventListener("error", () => {
      image.hidden = true;
      wrapper.appendChild(
        element("p", "inline-error", "Image preview could not be loaded.")
      );
    }, { once: true });

    wrapper.appendChild(image);
    parent.appendChild(wrapper);
  };

  const showTechnicalDetails = (parent, details) => {
    const disclosure = element("details", "technical-details");
    disclosure.appendChild(element("summary", "", "Technical details"));

    const pre = element("pre", "result-json");
    pre.textContent = JSON.stringify(details, null, 2);
    disclosure.appendChild(pre);
    parent.appendChild(disclosure);
  };

  const renderDetection = (result) => {
    const summary = section("Detection summary");
    const metrics = element("div", "metrics-grid");

    metric(metrics, "Objects detected", result.detection_count ?? result.detections?.length ?? 0);
    metric(metrics, "People predictions", result.people_count ?? 0);
    metric(metrics, "Model", result.model || "Not reported");
    metric(metrics, "Device", result.device || "Not reported");

    summary.appendChild(metrics);

    const detections = Array.isArray(result.detections) ? result.detections : [];
    const objectsSection = section("Detected objects");

    if (!detections.length) {
      objectsSection.appendChild(
        element("p", "empty-state", "No objects were detected at the configured threshold.")
      );
    } else {
      const list = element("div", "detection-list");

      detections.forEach((detection, index) => {
        const card = element("article", "detection-card");
        const header = element("div", "detection-card-header");
        const label = element("h4", "", detection.label || "Unknown object");
        const confidence = Number(detection.confidence);
        const confidenceText = Number.isFinite(confidence)
          ? `${(confidence * 100).toFixed(1)}%`
          : "Not reported";

        header.append(
          label,
          element("strong", "detection-confidence", confidenceText)
        );

        card.appendChild(header);

        if (Number.isFinite(confidence)) {
          const track = element("div", "confidence-track");
          const fill = element("div", "confidence-fill");
          fill.style.width = `${Math.max(0, Math.min(100, confidence * 100))}%`;
          track.appendChild(fill);
          card.appendChild(track);
        }

        const bbox = detection.bbox_xyxy;
        if (bbox) {
          card.appendChild(
            element(
              "p",
              "detection-coordinates",
              `Bounding box: (${bbox.x1}, ${bbox.y1}) → (${bbox.x2}, ${bbox.y2})`
            )
          );
        }

        card.appendChild(
          element("p", "record-meta", `Detection ${index + 1} · Class ID: ${detection.class_id ?? "—"}`)
        );

        list.appendChild(card);
      });

      objectsSection.appendChild(list);
    }

    const limitations = result.limitations;
    if (Array.isArray(limitations) && limitations.length) {
      const note = section("Interpretation and limitations");
      const list = element("ul", "limitation-list");

      limitations.forEach((item) => {
        list.appendChild(element("li", "", item));
      });

      note.appendChild(list);
    }

    const width = result.image_dimensions?.width;
    const height = result.image_dimensions?.height;

    const details = {
      analysis_type: result.analysis_type,
      source_image: result.source_image,
      image_dimensions: result.image_dimensions,
      model: result.model,
      device: result.device,
      confidence_threshold: result.confidence_threshold,
      analyzed_at_utc: result.analyzed_at_utc,
      annotated_image: result.annotated_image,
      json_output: result.json_output
    };

    if (width && height) {
      const metadata = section("Evidence metadata");
      const grid = element("div", "metrics-grid");
      metric(grid, "Image dimensions", `${width} × ${height}`);
      metric(grid, "Confidence threshold", `${(Number(result.confidence_threshold ?? 0) * 100).toFixed(0)}%`);
      metric(grid, "Source file", result.source_image || "Not reported");
      metadata.appendChild(grid);
    }

    showTechnicalDetails(container, details);
  };

  const renderDescription = (result) => {
    const descriptionSection = section("Scene description");
    const description =
      result.scene_description ??
      result.description ??
      result.caption ??
      result.summary;

    if (typeof description === "string") {
      descriptionSection.appendChild(
        element("p", "scene-description-text", description)
      );
    } else if (description !== undefined) {
      const pre = element("pre", "result-json");
      pre.textContent = JSON.stringify(description, null, 2);
      descriptionSection.appendChild(pre);
    } else {
      descriptionSection.appendChild(
        element("p", "empty-state", "The response did not contain a recognized description field.")
      );
    }
  };

  const renderCombined = (result) => {
    const heading = section("Combined image analysis");
    heading.appendChild(
      element(
        "p",
        "forensic-notice",
        result.notice || "AI-generated preliminary analysis. Verify findings against the original evidence."
      )
    );

    if (result.object_detection) renderDetection(result.object_detection);
    if (result.scene_description) renderDescription(result.scene_description);

    showTechnicalDetails(container, result);
  };

  if (data && typeof data === "object" && !Array.isArray(data)) {
    if (data.analysis_type === "multimodal_image_analysis") {
      renderCombined(data);
      return;
    }

    if (Array.isArray(data.detections) || data.analysis_type === "object_detection") {
      const title = element("h3", "analysis-result-heading", "Object detection results");
      container.appendChild(title);

      if (data.annotated_image) {
        const filename = data.annotated_image.split(/[\\/]/).pop();
        const safeFilename = encodeURIComponent(filename);

        const imageRow = element("div", "evidence-image-grid");

        showImage(
          imageRow,
          "Annotated image",
          `/api/detection-output/${safeFilename}`,
          "Annotated image with model detection boxes"
        );

        container.appendChild(imageRow);
      }

      renderDetection(data);
      showTechnicalDetails(container, data);
      return;
    }

    if (
      data.scene_description !== undefined ||
      data.description !== undefined ||
      data.caption !== undefined ||
      data.summary !== undefined
    ) {
      renderDescription(data);
      showTechnicalDetails(container, data);
      return;
    }
  }

  const fallback = element("pre", "result-json");
  fallback.textContent =
    typeof data === "string" ? data : JSON.stringify(data, null, 2);

  container.appendChild(fallback);
}


  function renderEmpty(container, message) {
    if (!container) return;

    container.replaceChildren();

    const paragraph = document.createElement("p");
    paragraph.className = "empty-state";
    paragraph.textContent = message;

    container.appendChild(paragraph);
  }

  function getActiveCaseId() {
    return state.activeCaseId || $("#case-select")?.value || "";
  }

  function navigateTo(viewName) {
    if (!viewConfig[viewName]) return;

    state.activeView = viewName;

    $$("[data-view]").forEach((button) => {
      const active = button.dataset.view === viewName;
      button.classList.toggle("active", active);
      button.setAttribute("aria-current", active ? "page" : "false");
    });

    Object.keys(viewConfig).forEach((name) => {
      const section = $(`#view-${name}`);
      if (section) section.hidden = name !== viewName;
    });

    const config = viewConfig[viewName];

    if ($("#page-title")) $("#page-title").textContent = config.title;
    if ($("#breadcrumb-current")) {
      $("#breadcrumb-current").textContent = config.title;
    }
    if ($("#page-description")) {
      $("#page-description").textContent = config.description;
    }

    clearNotice();

    if (viewName === "investigations") loadInvestigations();
    if (viewName === "reports") loadReports();
  }

  async function loadCases() {
    const select = $("#case-select");
    if (!select) return;

    try {
      const payload = await apiRequest("/api/cases");
      const cases = Array.isArray(payload)
        ? payload
        : Array.isArray(payload.cases)
          ? payload.cases
          : [];

      state.cases = cases;

      const previousId = getActiveCaseId();

      select.replaceChildren();

      const defaultOption = document.createElement("option");
      defaultOption.value = "";
      defaultOption.textContent = "Select investigation";
      select.appendChild(defaultOption);

      cases.forEach((item) => {
        const option = document.createElement("option");
        option.value = item.id ?? item.case_id ?? "";
        option.textContent =
          item.title || item.name || `Investigation ${option.value}`;

        select.appendChild(option);
      });

      const matchingCase = cases.find(
        (item) => String(item.id ?? item.case_id ?? "") === String(previousId)
      );

      if (matchingCase) {
        select.value = String(matchingCase.id ?? matchingCase.case_id);
      }

      state.activeCaseId = select.value;

      renderInvestigationList();
    } catch (error) {
      showNotice(`Could not load investigations: ${error.message}`, "error");
    }
  }

  async function createCase(event) {
    event.preventDefault();

    const title = $("#new-case-title")?.value.trim();
    const description = $("#new-case-description")?.value.trim();
    const status = $("#new-case-status")?.value;

    if (!title) {
      showNotice("Enter an investigation title first.", "error");
      return;
    }

    const submitButton = $("#create-case-submit");
    if (submitButton) submitButton.disabled = true;

    try {
      const payload = { title, description };

      if (status) payload.status = status;

      const result = await apiRequest("/api/cases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const createdCase = result.case || result;
      const createdId = createdCase.id ?? createdCase.case_id;

      await loadCases();

      if (createdId != null && $("#case-select")) {
        $("#case-select").value = String(createdId);
        state.activeCaseId = String(createdId);
      }

      $("#new-case-dialog")?.close();
      $("#new-case-form")?.reset();

      showNotice("Investigation created successfully.", "success");
      await loadInvestigations();
    } catch (error) {
      showNotice(`Could not create investigation: ${error.message}`, "error");
    } finally {
      if (submitButton) submitButton.disabled = false;
    }
  }

  function renderInvestigationList() {
    const container = $("#investigation-list");
    if (!container) return;

    container.replaceChildren();

    if (!state.cases.length) {
      renderEmpty(container, "No investigations found. Create one to get started.");
      return;
    }

    state.cases.forEach((item) => {
      const id = item.id ?? item.case_id ?? "";
      const card = document.createElement("article");
      card.className = "investigation-card";

      const heading = document.createElement("h3");
      heading.textContent = item.title || item.name || `Investigation ${id}`;

      const details = document.createElement("p");
      details.textContent = item.description || "No description provided.";

      const metadata = document.createElement("p");
      metadata.className = "record-meta";
      metadata.textContent =
        `Status: ${item.status || "Unknown"} · ` +
        `Evidence: ${item.evidence_count ?? 0} · ` +
        `Analyses: ${item.analysis_count ?? 0}`;

      const openButton = document.createElement("button");
      openButton.type = "button";
      openButton.className = "button button-secondary";
      openButton.textContent = "Select investigation";

      openButton.addEventListener("click", () => {
        const select = $("#case-select");
        if (select) select.value = String(id);

        state.activeCaseId = String(id);
        showNotice(`Selected: ${heading.textContent}`, "success");
      });

      card.append(heading, details, metadata, openButton);
      container.appendChild(card);
    });
  }

  async function loadInvestigations() {
    await loadCases();

    const caseId = getActiveCaseId();

    if (!caseId) {
      renderEmpty($("#evidence-list"), "Select an investigation to view its evidence.");
      renderEmpty($("#case-analysis-list"), "Select an investigation to view its analyses.");
      return;
    }

    const evidenceContainer = $("#evidence-list");
    const analysisContainer = $("#case-analysis-list");

    try {
      const [evidencePayload, analysisPayload] = await Promise.all([
        apiRequest(`/api/cases/${encodeURIComponent(caseId)}/evidence`),
        apiRequest(`/api/cases/${encodeURIComponent(caseId)}/analyses`)
      ]);

      renderRecordList(
        evidenceContainer,
        evidencePayload.evidence || [],
        "No evidence registered for this investigation."
      );

      renderRecordList(
        analysisContainer,
        analysisPayload.analyses || [],
        "No saved analyses for this investigation."
      );
    } catch (error) {
      showNotice(`Could not load investigation records: ${error.message}`, "error");
    }
  }

  function renderRecordList(container, records, emptyMessage) {
    if (!container) return;

    container.replaceChildren();

    if (!records.length) {
      renderEmpty(container, emptyMessage);
      return;
    }

    records.forEach((record) => {
      const card = document.createElement("article");
      card.className = "record-card";

      const heading = document.createElement("h3");
      heading.textContent =
        record.original_filename ||
        record.filename ||
        record.title ||
        record.name ||
        record.analysis_type ||
        "Evidence record";

      const metadata = document.createElement("p");
      metadata.className = "record-meta";
      metadata.textContent = [
        record.modality,
        record.status,
        record.created_at
      ].filter(Boolean).join(" · ") || "Record details available";

      card.append(heading, metadata);
      container.appendChild(card);
    });
  }

  async function loadReports() {
    const container = $("#report-list");
    if (!container) return;

    container.replaceChildren();

    const cases = state.cases;

    if (!cases.length) {
      await loadCases();
    }

    if (!state.cases.length) {
      renderEmpty(container, "No investigations are available yet.");
      return;
    }

    const heading = document.createElement("p");
    heading.className = "empty-state";
    heading.textContent =
      "Saved analysis records are listed by investigation below.";
    container.appendChild(heading);

    for (const item of state.cases) {
      const id = item.id ?? item.case_id;
      if (id == null) continue;

      const section = document.createElement("section");
      section.className = "report-group";

      const title = document.createElement("h3");
      title.textContent = item.title || `Investigation ${id}`;
      section.appendChild(title);

      try {
        const payload = await apiRequest(
          `/api/cases/${encodeURIComponent(id)}/analyses`
        );

        const records = payload.analyses || [];

        if (!records.length) {
          const empty = document.createElement("p");
          empty.textContent = "No saved analyses.";
          section.appendChild(empty);
        } else {
          records.forEach((record) => {
            const entry = document.createElement("article");
            entry.className = "record-card";

            const name = document.createElement("h4");
            name.textContent =
              record.analysis_type || record.title || "Analysis record";

            const details = document.createElement("p");
            details.textContent =
              record.created_at || record.status || "Saved analysis";

            entry.append(name, details);
            section.appendChild(entry);
          });
        }
      } catch (error) {
        const message = document.createElement("p");
        message.textContent = `Unable to load records: ${error.message}`;
        section.appendChild(message);
      }

      container.appendChild(section);
    }
  }

  function setupNavigation() {
    $$("[data-view]").forEach((button) => {
      button.addEventListener("click", () => {
        navigateTo(button.dataset.view);
      });
    });

    $("#case-select")?.addEventListener("change", (event) => {
      state.activeCaseId = event.target.value;

      if (state.activeView === "investigations") loadInvestigations();
      if (state.activeView === "reports") loadReports();
    });

    $("#refresh-cases")?.addEventListener("click", loadCases);
    $("#investigation-refresh")?.addEventListener("click", loadInvestigations);
    $("#reports-refresh")?.addEventListener("click", loadReports);

    $("#new-case-button")?.addEventListener("click", () => {
      $("#new-case-dialog")?.showModal();
    });

    $("#close-case-dialog")?.addEventListener("click", () => {
      $("#new-case-dialog")?.close();
    });

    $("#cancel-case-dialog")?.addEventListener("click", () => {
      $("#new-case-dialog")?.close();
    });

    $("#new-case-form")?.addEventListener("submit", createCase);
  }

  function setupFilePreview(inputId, previewId, emptyId, metaId, allowedTypes) {
    const input = $(`#${inputId}`);
    const preview = $(`#${previewId}`);
    const empty = $(`#${emptyId}`);
    const meta = $(`#${metaId}`);

    if (!input) return;

    input.addEventListener("change", () => {
      const file = input.files?.[0];

      if (!file) {
        if (preview) {
          preview.hidden = true;
          if (preview.tagName === "IMG") preview.removeAttribute("src");
          if (preview.tagName === "VIDEO") preview.removeAttribute("src");
          if (preview.tagName === "AUDIO") preview.removeAttribute("src");
        }

        if (empty) empty.hidden = false;
        if (meta) meta.textContent = "";
        return;
      }

      if (allowedTypes && !allowedTypes.includes(file.type) &&
          !allowedTypes.some((type) => file.name.toLowerCase().endsWith(type))) {
        showNotice("This file type may not be supported. Check the accepted formats.", "error");
      }

      const sizeLabel = `${(file.size / (1024 * 1024)).toFixed(2)} MB`;
      if (meta) meta.textContent = `${file.name} · ${sizeLabel}`;

      if (preview && ["IMG", "VIDEO", "AUDIO"].includes(preview.tagName)) {
        const objectUrl = URL.createObjectURL(file);
        preview.src = objectUrl;
        preview.hidden = false;

        if (empty) empty.hidden = true;

        preview.addEventListener("load", () => URL.revokeObjectURL(objectUrl), { once: true });
        preview.addEventListener("error", () => URL.revokeObjectURL(objectUrl), { once: true });
        preview.addEventListener("loadedmetadata", () => URL.revokeObjectURL(objectUrl), { once: true });
      }
    });
  }

  function setupAudioControls() {
    $("#audio-operation")?.addEventListener("change", (event) => {
      const operation = event.target.value;
      const existingInputs = $("#audio-existing-inputs");

      if (existingInputs) {
        existingInputs.hidden = operation === "full" || operation === "transcribe";
      }
    });

    $$("#audio-result-tabs [data-audio-result]").forEach((button) => {
      button.addEventListener("click", () => {
        const resultType = button.dataset.audioResult;

        $$("#audio-result-tabs [data-audio-result]").forEach((tab) => {
          tab.classList.toggle("active", tab === button);
        });

        const data = state.currentResults.audio[resultType];

        renderResult(
          $("#audio-results"),
          data ?? `No ${resultType} result available yet.`
        );
      });
    });
  }

  function setupVideoControls() {
    $("#video-confidence")?.addEventListener("input", (event) => {
      const value = Number(event.target.value);

      if ($("#video-confidence-value")) {
        $("#video-confidence-value").textContent = value.toFixed(2);
      }
    });
  }

  function setupForms() {
    $("#image-form")?.addEventListener("submit", (event) => {
      event.preventDefault();
      handleImageAnalysis();
    });

    $("#audio-form")?.addEventListener("submit", (event) => {
      event.preventDefault();
      handleAudioAnalysis();
    });

    $("#video-form")?.addEventListener("submit", (event) => {
      event.preventDefault();
      handleVideoAnalysis();
    });
  }

  
async function handleImageAnalysis() {
  const form = $("#image-form");
  const fileInput = $("#image-file");
  const operation = $("#image-operation")?.value || "analyze";
  const submitButton = $("#image-submit");
  const status = $("#image-status");
  const results = $("#image-results");
  const resultState = $("#image-result-state");

  const file = fileInput?.files?.[0];

  if (!file) {
    setStatus(status, "Choose an image before starting analysis.", "error");
    return;
  }

  const allowedExtensions = [".jpg", ".jpeg", ".png", ".webp"];
  const filename = file.name.toLowerCase();

  if (!allowedExtensions.some((extension) => filename.endsWith(extension))) {
    setStatus(status, "Unsupported image format. Use JPG, JPEG, PNG, or WEBP.", "error");
    return;
  }

  if (file.size === 0) {
    setStatus(status, "The selected image is empty.", "error");
    return;
  }

  const endpointByOperation = {
    detect: "/api/detect",
    describe: "/api/describe",
    analyze: "/api/analyze"
  };

  const endpoint = endpointByOperation[operation];

  if (!endpoint) {
    setStatus(status, "Select a valid image analysis operation.", "error");
    return;
  }

  submitButton.disabled = true;
  submitButton.classList.add("loading");
  setStatus(status, "Preparing image analysis…");
  if (resultState) resultState.textContent = "Analysis in progress";
  renderEmpty(results, "Processing image evidence. Please wait.");

  try {
    const caseId = getActiveCaseId();

    // Register a copy with the selected investigation, if one is selected.
    // The analysis endpoint also receives the file because the current API
    // accepts multipart uploads directly.
    if (caseId) {
      setStatus(status, "Registering image with the selected investigation…");

      const evidenceForm = new FormData();
      evidenceForm.append("modality", "image");
      evidenceForm.append("image", file);

      await apiRequest(
        `/api/cases/${encodeURIComponent(caseId)}/evidence`,
        {
          method: "POST",
          body: evidenceForm
        }
      );
    }

    setStatus(status, "Running image analysis…");

    const analysisForm = new FormData();
    analysisForm.append("image", file);

    if ($("#image-notes")?.value.trim()) {
      analysisForm.append("notes", $("#image-notes").value.trim());
    }

    const data = await apiRequest(endpoint, {
      method: "POST",
      body: analysisForm
    });

    state.currentResults.image = data;
    renderResult(results, data);

    if (resultState) resultState.textContent = "Analysis completed";

    setStatus(
      status,
      caseId
        ? "Analysis completed. Evidence was registered with the selected investigation."
        : "Analysis completed successfully.",
      "success"
    );

    // Refresh investigation records so the new evidence is visible.
    if (caseId) {
      await loadCases();

      if (state.activeView === "investigations") {
        await loadInvestigations();
      }

      if (state.activeView === "reports") {
        await loadReports();
      }
    }
  } catch (error) {
    if (resultState) resultState.textContent = "Analysis failed";
    setStatus(status, `Image analysis failed: ${error.message}`, "error");
    renderEmpty(results, "No successful analysis result is available.");
  } finally {
    submitButton.disabled = false;
    submitButton.classList.remove("loading");
  }
}


  async function handleAudioAnalysis() {
    showNotice(
      "Audio analysis handler is the next implementation step.",
      "info"
    );
  }

  async function handleVideoAnalysis() {
    showNotice(
      "Video analysis handler is the next implementation step.",
      "info"
    );
  }

  function initialize() {
    setupNavigation();

    setupFilePreview(
      "image-file",
      "image-preview",
      "image-preview-empty",
      "image-preview-meta",
      [".jpg", ".jpeg", ".png", ".webp"]
    );

    setupFilePreview(
      "audio-file",
      "audio-preview",
      "audio-preview-empty",
      "audio-preview-meta",
      [".mp3", ".m4a", ".wav", ".ogg", ".flac", ".webm"]
    );

    setupFilePreview(
      "video-file",
      "video-preview",
      "video-preview-empty",
      "video-preview-meta",
      [".mp4", ".avi", ".mov", ".mkv", ".webm"]
    );

    setupAudioControls();
    setupVideoControls();
    setupForms();

    renderEmpty($("#image-results"), "Run an image analysis to see results here.");
    renderEmpty($("#audio-results"), "Run an audio analysis to see results here.");
    renderEmpty($("#video-results"), "Run a video analysis to see results here.");

    navigateTo("image");
    loadCases();
  }

  initialize();
});
